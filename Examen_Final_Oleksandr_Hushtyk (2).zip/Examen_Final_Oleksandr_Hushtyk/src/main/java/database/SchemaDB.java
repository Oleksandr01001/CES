package database;

public class SchemaDB {
    public static final String TAB_PRODUCTOS = "productos";
    public static final String COL_ID = "id";
    public static final String COL_NOMBRE = "nombre";
    public static final String COL_PRECIO = "precio";
    public static final String COL_CANTIDAD = "cantidad";
}
