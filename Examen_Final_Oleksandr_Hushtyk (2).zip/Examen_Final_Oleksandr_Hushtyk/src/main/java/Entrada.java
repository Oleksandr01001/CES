import controller.GestorProductos;

public class Entrada {

    public static void main(String[] args) {
        GestorProductos gestorProductos = new GestorProductos();

        gestorProductos.menu();
    }
}
