import java.io.File;

public class OperacionesFicheros {


    public void leerInformacion() {
        File file = new File("C:\\Users\\oleks\\Documents\\GitHub\\Oleksandr_Hushtyk_PRO\\Ficheros\\src\\recursos\\ejemplo.txt");
        System.out.println(file.isFile());
    }



    public void listarTodo(String ruta) {
        File carpeta = new File(ruta);
        mostrarContenido(carpeta, "");
    }

    private void mostrarContenido(File carpeta, String espacio) {

        File[] lista = carpeta.listFiles();


        for (File item : lista) {
            if (item.isDirectory()) {
                System.out.println(espacio + "[Carpeta] " + item.getName());
                mostrarContenido(item, espacio + "    ");
            } else {
                System.out.println(espacio + "[Archivo] " + item.getName());
            }
        }
    }
}

