public class Entrada {

    public static void main(String[] args) {
        OperacionesFicheros operacionesFicheros = new OperacionesFicheros();



        operacionesFicheros.listarTodo("C:\\Users\\oleks\\Documents\\GitHub\\Oleksandr_Hushtyk_PRO");
    }
}
