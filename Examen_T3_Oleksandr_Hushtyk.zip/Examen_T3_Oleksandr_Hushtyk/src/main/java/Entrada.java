import controller.CentroFormacion;
import database.DBConnector;

public class Entrada {

    public static void main(String[] args) {


        CentroFormacion centroFormacion = new CentroFormacion();
        centroFormacion.menu();
    }
}
