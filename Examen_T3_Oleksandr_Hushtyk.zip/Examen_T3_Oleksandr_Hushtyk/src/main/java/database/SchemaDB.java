package database;

public class SchemaDB {
    public static final String TAB_PROFESORES = "profesores";
    public static final String COL_NOMBRE = "nombre";
    public static final String COL_DNI = "dni";
    public static final String COL_SALARIO = "salario";
}
