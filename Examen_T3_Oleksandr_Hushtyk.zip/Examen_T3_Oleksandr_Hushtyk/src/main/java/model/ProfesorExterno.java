package model;

public class ProfesorExterno extends Profesor{

    private int numeroHoras = 50;
    private double precioHora = 20;

    public ProfesorExterno() {
    }

    public ProfesorExterno(String nombre, String dni, String salario, int numeroHoras, double precioHora) {
        super(nombre, dni, salario);
        this.numeroHoras = numeroHoras;
        this.precioHora = precioHora;
    }

    public String mostrarDatos() {
        super.mostrarDatos();

        return "ProfesorExterno{" +
                "numeroHoras=" + numeroHoras +
                ", precioHora=" + precioHora +
                '}';
    }




    public void calcularSalario() {

        setSalario((numeroHoras * precioHora) + getSalario() );

    }




    public int getNumeroHoras() {
        return numeroHoras;
    }

    public void setNumeroHoras(int numeroHoras) {
        this.numeroHoras = numeroHoras;
    }

    public double getPrecioHora() {
        return precioHora;
    }

    public void setPrecioHora(double precioHora) {
        this.precioHora = precioHora;
    }
}
