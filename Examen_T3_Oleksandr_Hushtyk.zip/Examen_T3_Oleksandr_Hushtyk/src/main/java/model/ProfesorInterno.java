package model;

public class ProfesorInterno extends Profesor{

    private int complemento = 300;

    public ProfesorInterno() {
    }

    public ProfesorInterno(String nombre, String dni, String salario, int complemento) {
        super(nombre, dni, salario);
        this.complemento = complemento;
    }


    public String mostrarDatos() {
        super.mostrarDatos();

        return "complemento= "+complemento;
    }



    public void calcuralSalario() {
        setSalario(getSalario()+complemento);
    }

    public int getComplemento() {
        return complemento;
    }

    public void setComplemento(int complemento) {
        this.complemento = complemento;
    }
}
