package model;

public class Profesor {

    private String nombre;
    private String dni;
    private String salario;

    public Profesor() {
    }

    public Profesor(String nombre, String dni, String salario) {
        this.nombre = nombre;
        this.dni = dni;
        this.salario = salario;
    }



    public String mostrarDatos() {
        return "Profesor{" +
                "nombre='" + nombre + '\'' +
                ", dni='" + dni + '\'' +
                ", salario='" + salario + '\'' +
                '}';
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }
}
