package model;


import database.DBConnector;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import static database.DBConnector.connection;

public class ProfesorDTO {

    DBConnector dbConnector = new DBConnector();

    public void realizarInsercion(){
        try {
            Connection connection = null;
            if (!connection.isClosed()){
                Statement statement = connection.createStatement();
                String nombre = "ejemplo";
                String  = "ejemplo";
                String query = "INSERT INTO usuario (nombre,apellido,telefono) " +
                        "VALUES ('%s','%s',%d)";
                statement.execute(String.format(query,usuario,apellido,123));
                statement.close();
                statement.getConnection().close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
