package controller;

import model.Profesor;
import model.ProfesorExterno;

import java.util.Scanner;

public class CentroFormacion {

    private int opcion = 0;

    private String nombre;
    private String dni;
    private double salario;

    static Scanner scanner = new Scanner(System.in);

    Profesor profesor = new Profesor();

    public void menu() {


        do {

            System.out.println("1.Mostrar profesores");
            System.out.println("2.Incorporar profesor");
            System.out.println("3.Dar de baja profesor");
            System.out.println("4.Exportar datos a base de datos");
            System.out.println("5.Exportar datos a csv");
            System.out.println("6.Exportar datos a fichero obj");
            System.out.println("0.Salir de la aplicacion");

            System.out.println("Elige la opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {

                case 1: {

                }
                case 2: {
                    System.out.println("Introduce nombre del profesor: ");
                    nombre = scanner.next();
                    System.out.println("Introduce dni del profesor: ");
                    dni = scanner.next();
                    System.out.println("Introduce salario del profesor: ");
                    salario = scanner.nextDouble();





                }
                case 3: {

                }
                case 4: {

                }
                case 5: {

                }
                case 6: {

                }
                case 0: {
                    System.out.println("Saliendo de la aplicacion...");
                }
            }

        } while (opcion != 0);
    }
}
