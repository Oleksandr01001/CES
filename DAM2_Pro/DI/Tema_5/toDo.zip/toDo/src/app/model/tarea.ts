export interface tarea {
  nombre: string | undefined;
  responsable: string | undefined;
  items: string[];
  fecha: string | undefined;
  prioridad: number;
  descipcion: string | undefined;
}