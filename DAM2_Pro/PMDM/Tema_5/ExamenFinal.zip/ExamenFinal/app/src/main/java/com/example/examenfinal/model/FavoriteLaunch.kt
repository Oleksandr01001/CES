package com.example.spacexlaunches.model

data class FavoriteLaunch(
    var id: String? = null,
    var name: String? = null,
    var details: String? = null,
    var imageUrl: String? = null
)
