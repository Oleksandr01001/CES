package utils;

public class ConstruccionException extends RuntimeException {
    public ConstruccionException(String message) {
        super(message);
    }
}
