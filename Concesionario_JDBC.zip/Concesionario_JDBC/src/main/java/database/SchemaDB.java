//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package database;

public class SchemaDB {
    public static final String TAB_COCHES = "coches";
    public static final String COL_ID_COCHE = "id";
    public static final String COL_MARCA = "marca";
    public static final String COL_COLOR = "color";
    public static final String COL_MODELO = "modelo";
    public static final String COL_MATRICULA = "matricula";
    public static final String COL_PRECIO = "precio";
    public static final String COL_ID_PASAJERO_FK = "id_pasajero";
    public static final String TAB_PASAJEROS = "pasajeros";
    public static final String COL_ID_PASAJERO = "id";
    public static final String COL_NOMBRE = "nombre";
    public static final String COL_EDAD = "edad";
    public static final String COL_PESO = "peso";

    public SchemaDB() {
    }
}
